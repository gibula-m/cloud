export const hello = () => {
  console.log("HELLo");

  return "test";
};
